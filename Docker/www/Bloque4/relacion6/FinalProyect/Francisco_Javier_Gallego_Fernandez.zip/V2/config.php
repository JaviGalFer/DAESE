<?php
define('DBHOST', 'db');        // Nombre del servidor de bases de datos 
define('DBUSER', 'root');         // Usuario para ese servidor
define('DBPASS', 'test');      // Contraseña para ese servidor
define('DBNAME', 'tareas');   // Nombre de la base de datos
