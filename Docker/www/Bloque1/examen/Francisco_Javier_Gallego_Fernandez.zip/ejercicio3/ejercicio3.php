<!-- 
    @author: Fco Javier Gallego Fernández
    curso: 2ºDAW
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Numeros primso 1 al 1000</title>
</head>
<body>
    <h2>Muestra numeros primos entre el 1 y el 1000</h2>
    <form action="mostrarPrimos.php" method="post">
        <label for="numero">Introduce un número entero entre el 1 y el 1000:</label>
        <input type="number" id="numero" name="numero">
        <input type="submit" value="Comprobar">
    </form>
    
    
</body>
</html>